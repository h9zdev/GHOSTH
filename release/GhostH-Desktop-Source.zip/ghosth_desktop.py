#!/usr/bin/env python3
"""
GhostH Desktop Suite — Cross-Platform Wardriving, WiGLE Uploader & Hardware Companion
Compatible with Windows, Linux, and macOS.
"""

import sys
import os
import time
import json
import glob
import socket
import threading
import datetime
import shutil
import subprocess
import requests
from requests.auth import HTTPBasicAuth

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

try:
    import serial
    import serial.tools.list_ports
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

CONFIG_FILE = os.path.expanduser("~/.ghosth_desktop_config.json")

class GhostHDesktopApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GhostH // Tactical Desktop Suite v2.2")
        self.root.geometry("980x680")
        self.root.minsize(850, 580)
        self.root.configure(bg="#050505")

        # In-memory storage for discovered networks: bssid -> dict
        self.networks = {}
        self.alpr_events = []
        self.serial_conn = None
        self.serial_thread = None
        self.is_serial_running = False

        self.wifi_socket = None
        self.is_wifi_running = False

        self.sync_server_sock = None
        self.is_sync_server_running = False

        self.icon_photo = None
        self.header_icon_img = None
        self.set_window_icon()

        self.load_config()
        self.setup_styles()
        self.build_ui()
        self.auto_refresh_ports()

        # Seamless Linux desktop registration on first launch
        if sys.platform.startswith("linux"):
            desktop_file = os.path.expanduser("~/.local/share/applications/ghosth.desktop")
            if not os.path.exists(desktop_file):
                self.register_linux_desktop_entry(notify=False)

    def set_window_icon(self):
        self.icon_photo = None
        self.header_icon_img = None
        try:
            if getattr(sys, 'frozen', False):
                base_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
            else:
                base_dir = os.path.dirname(os.path.abspath(__file__))

            candidates = [
                os.path.join(base_dir, "ghosth_icon.png"),
                os.path.join(base_dir, "ghosth.png"),
                os.path.expanduser("~/.local/share/icons/hicolor/512x512/apps/ghosth.png"),
                os.path.expanduser("~/.local/share/pixmaps/ghosth.png"),
                "/usr/share/icons/hicolor/512x512/apps/ghosth.png",
                "/usr/share/pixmaps/ghosth.png",
            ]
            icon_file = None
            for p in candidates:
                if os.path.isfile(p):
                    icon_file = p
                    break

            if icon_file:
                if HAS_PIL:
                    pil_img = Image.open(icon_file)
                    self.icon_photo = ImageTk.PhotoImage(pil_img)
                    self.root.iconphoto(True, self.icon_photo)
                    header_pil = pil_img.resize((26, 26), Image.Resampling.LANCZOS)
                    self.header_icon_img = ImageTk.PhotoImage(header_pil)
                else:
                    self.icon_photo = tk.PhotoImage(file=icon_file)
                    self.root.iconphoto(True, self.icon_photo)
                    self.header_icon_img = self.icon_photo.subsample(max(1, self.icon_photo.width() // 26))
        except Exception as e:
            pass

    def register_linux_desktop_entry(self, notify=False):
        if not sys.platform.startswith("linux"):
            if notify:
                messagebox.showinfo("Linux App Registration", "This feature is only applicable on Linux.")
            return

        try:
            home = os.path.expanduser("~")
            apps_dir = os.path.join(home, ".local", "share", "applications")
            icons_dir = os.path.join(home, ".local", "share", "icons", "hicolor", "512x512", "apps")
            pixmaps_dir = os.path.join(home, ".local", "share", "pixmaps")
            bin_dir = os.path.join(home, ".local", "bin")

            os.makedirs(apps_dir, exist_ok=True)
            os.makedirs(icons_dir, exist_ok=True)
            os.makedirs(pixmaps_dir, exist_ok=True)
            os.makedirs(bin_dir, exist_ok=True)

            target_icon = os.path.join(icons_dir, "ghosth.png")
            target_pixmap = os.path.join(pixmaps_dir, "ghosth.png")

            # Locate source icon
            if getattr(sys, 'frozen', False):
                base_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
            else:
                base_dir = os.path.dirname(os.path.abspath(__file__))

            src_icon = None
            for cand in ["ghosth_icon.png", "ghosth.png"]:
                p = os.path.join(base_dir, cand)
                if os.path.exists(p):
                    src_icon = p
                    break

            if src_icon and os.path.exists(src_icon):
                shutil.copy2(src_icon, target_icon)
                shutil.copy2(src_icon, target_pixmap)

            # Determine execution command
            if getattr(sys, 'frozen', False):
                current_bin = os.path.abspath(sys.executable)
                target_bin = os.path.join(bin_dir, "ghosth-desktop")
                try:
                    if os.path.abspath(current_bin) != os.path.abspath(target_bin):
                        shutil.copy2(current_bin, target_bin)
                        os.chmod(target_bin, 0o755)
                    exec_cmd = target_bin
                except Exception:
                    exec_cmd = current_bin
            else:
                current_script = os.path.abspath(__file__)
                exec_cmd = f"python3 \"{current_script}\""

            desktop_content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=GhostH
GenericName=Tactical Wardrive & SIGINT Suite
Comment=GhostH RF Signal Intelligence, Wardriving & Surveillance Suite
Exec={exec_cmd}
Icon=ghosth
Terminal=false
Categories=Network;Security;Utility;
Keywords=wardrive;wifi;alpr;sigint;wigle;ghosth;
StartupWMClass=ghosth-desktop
"""
            desktop_path = os.path.join(apps_dir, "ghosth.desktop")
            with open(desktop_path, "w", encoding="utf-8") as f:
                f.write(desktop_content)
            os.chmod(desktop_path, 0o755)

            # Update desktop database
            try:
                subprocess.run(["update-desktop-database", apps_dir], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

            if notify:
                messagebox.showinfo("App Registered", f"GhostH successfully registered in Linux Applications menu!\n\nLauncher: {desktop_path}\nIcon: {target_icon}")
        except Exception as ex:
            if notify:
                messagebox.showerror("Registration Error", f"Failed to register in Linux Applications menu: {ex}")

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Color palette
        self.BG_DARK = "#050505"
        self.PANEL_BG = "#0A0A0A"
        self.PRIMARY_CYAN = "#00FFD1"
        self.TEXT_DIM = "#5A8A8A"
        self.ACCENT_RED = "#CC3333"
        self.ACCENT_YELLOW = "#FFBF00"

        style.configure(".", background=self.BG_DARK, foreground=self.PRIMARY_CYAN, font=("Courier New", 10))
        style.configure("TNotebook", background=self.BG_DARK, borderwidth=0)
        style.configure("TNotebook.Tab", background="#121212", foreground=self.TEXT_DIM, padding=[12, 6], font=("Courier New", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", self.PANEL_BG)], foreground=[("selected", self.PRIMARY_CYAN)])

        style.configure("TFrame", background=self.BG_DARK)
        style.configure("Panel.TFrame", background=self.PANEL_BG, relief="solid", borderwidth=1)
        style.configure("TLabel", background=self.BG_DARK, foreground=self.PRIMARY_CYAN)
        style.configure("Dim.TLabel", foreground=self.TEXT_DIM)
        style.configure("Highlight.TLabel", foreground="#FFFFFF", font=("Courier New", 11, "bold"))

        style.configure("TButton", background="#0C1820", foreground=self.PRIMARY_CYAN, borderwidth=1, focuscolor="none", font=("Courier New", 9, "bold"))
        style.map("TButton", background=[("active", self.PRIMARY_CYAN)], foreground=[("active", "#050505")])

        style.configure("Action.TButton", background="#003830", foreground=self.PRIMARY_CYAN, font=("Courier New", 10, "bold"))
        style.map("Action.TButton", background=[("active", self.PRIMARY_CYAN)], foreground=[("active", "#050505")])

        style.configure("Treeview", background="#0A0A0A", foreground="#FFFFFF", fieldbackground="#0A0A0A", rowheight=24, font=("Courier New", 9))
        style.configure("Treeview.Heading", background="#12181E", foreground=self.PRIMARY_CYAN, font=("Courier New", 9, "bold"))
        style.map("Treeview", background=[("selected", "#00473E")], foreground=[("selected", self.PRIMARY_CYAN)])

    def build_ui(self):
        # Header banner
        header = tk.Frame(self.root, bg=self.PANEL_BG, bd=1, relief="solid", height=50)
        header.pack(fill="x", padx=8, pady=(8, 4))

        if self.header_icon_img:
            icon_lbl = tk.Label(header, image=self.header_icon_img, bg=self.PANEL_BG)
            icon_lbl.pack(side="left", padx=(10, 4), pady=8)

        title_lbl = tk.Label(header, text="// GHOSTH DESKTOP SUITE", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN, font=("Courier New", 13, "bold"))
        title_lbl.pack(side="left", padx=4, pady=8)

        self.status_lbl = tk.Label(header, text="SYSTEM READY | DISCONNECTED", bg=self.PANEL_BG, fg=self.TEXT_DIM, font=("Courier New", 9))
        self.status_lbl.pack(side="right", padx=12, pady=8)

        if sys.platform.startswith("linux"):
            btn_reg = ttk.Button(header, text="ADD TO LINUX APPS", command=lambda: self.register_linux_desktop_entry(notify=True))
            btn_reg.pack(side="right", padx=6, pady=8)

        # Tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=8, pady=4)

        # Tab 1: Hardware Ingestion (NodeMCU USB & Wi-Fi)
        self.tab_hardware = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_hardware, text=" [1] HARDWARE INGEST ")
        self.build_hardware_tab()

        # Tab 2: WiGLE API Direct Uploader
        self.tab_wigle = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_wigle, text=" [2] WIGLE API UPLOAD ")
        self.build_wigle_tab()

        # Tab 3: Mobile Phone Network Sync
        self.tab_sync = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_sync, text=" [3] MOBILE APP SYNC ")
        self.build_sync_tab()

        # Tab 4: Spatial Analytics & Log
        self.tab_analytics = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_analytics, text=" [4] RF ANALYTICS ")
        self.build_analytics_tab()

        # Bottom status bar
        bottom_bar = tk.Frame(self.root, bg="#080808", height=24)
        bottom_bar.pack(fill="x", side="bottom")

        self.stats_summary_lbl = tk.Label(bottom_bar, text="Observations: 0 | ALPR Detections: 0 | Uptime: 0s", bg="#080808", fg=self.TEXT_DIM, font=("Courier New", 8))
        self.stats_summary_lbl.pack(side="left", padx=10)

        dev_link = tk.Label(bottom_bar, text="Developer: haybnz.web.app", bg="#080808", fg=self.PRIMARY_CYAN, font=("Courier New", 8), cursor="hand2")
        dev_link.pack(side="right", padx=10)
        dev_link.bind("<Button-1>", lambda e: self.open_url("https://haybnz.web.app/"))

    def build_hardware_tab(self):
        ctrl_frame = tk.Frame(self.tab_hardware, bg=self.PANEL_BG, bd=1, relief="solid")
        ctrl_frame.pack(fill="x", padx=6, pady=6)

        # Serial settings
        tk.Label(ctrl_frame, text="USB SERIAL PORT:", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN).grid(row=0, column=0, padx=6, pady=8, sticky="w")
        self.port_combo = ttk.Combobox(ctrl_frame, width=16)
        self.port_combo.grid(row=0, column=1, padx=4, pady=8)

        tk.Label(ctrl_frame, text="BAUD:", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN).grid(row=0, column=2, padx=4, pady=8)
        self.baud_combo = ttk.Combobox(ctrl_frame, width=8, values=["115200", "9600", "57600", "230400", "460800"])
        self.baud_combo.set("115200")
        self.baud_combo.grid(row=0, column=3, padx=4, pady=8)

        self.btn_serial_toggle = ttk.Button(ctrl_frame, text="CONNECT USB SERIAL", command=self.toggle_serial)
        self.btn_serial_toggle.grid(row=0, column=4, padx=8, pady=8)

        ttk.Button(ctrl_frame, text="REFRESH PORTS", command=self.auto_refresh_ports).grid(row=0, column=5, padx=4, pady=8)

        # Wi-Fi AP settings
        tk.Label(ctrl_frame, text="GHOSTH WI-FI STREAM (192.168.4.1:8888):", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN).grid(row=1, column=0, columnspan=2, padx=6, pady=4, sticky="w")
        self.btn_wifi_toggle = ttk.Button(ctrl_frame, text="CONNECT WI-FI AP STREAM", command=self.toggle_wifi_ap)
        self.btn_wifi_toggle.grid(row=1, column=2, columnspan=2, padx=4, pady=4, sticky="w")

        # Table of scanned networks
        table_frame = tk.Frame(self.tab_hardware, bg=self.BG_DARK)
        table_frame.pack(fill="both", expand=True, padx=6, pady=4)

        columns = ("bssid", "ssid", "rssi", "chan", "freq", "time")
        self.tree_aps = ttk.Treeview(table_frame, columns=columns, show="headings")
        self.tree_aps.heading("bssid", text="BSSID (MAC)")
        self.tree_aps.heading("ssid", text="SSID (NETWORK NAME)")
        self.tree_aps.heading("rssi", text="RSSI")
        self.tree_aps.heading("chan", text="CH")
        self.tree_aps.heading("freq", text="FREQ")
        self.tree_aps.heading("time", text="LAST SEEN")

        self.tree_aps.column("bssid", width=140, anchor="w")
        self.tree_aps.column("ssid", width=240, anchor="w")
        self.tree_aps.column("rssi", width=70, anchor="center")
        self.tree_aps.column("chan", width=50, anchor="center")
        self.tree_aps.column("freq", width=70, anchor="center")
        self.tree_aps.column("time", width=150, anchor="w")

        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree_aps.yview)
        self.tree_aps.configure(yscrollcommand=scroll.set)
        self.tree_aps.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def build_wigle_tab(self):
        form_frame = tk.Frame(self.tab_wigle, bg=self.PANEL_BG, bd=1, relief="solid")
        form_frame.pack(fill="x", padx=10, pady=10)

        tk.Label(form_frame, text="// WIGLE API CONFIGURATION", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN, font=("Courier New", 11, "bold")).grid(row=0, column=0, columnspan=2, padx=12, pady=(10, 6), sticky="w")
        tk.Label(form_frame, text="Generate your API Name & Token at https://wigle.net/account", bg=self.PANEL_BG, fg=self.TEXT_DIM, font=("Courier New", 9)).grid(row=1, column=0, columnspan=2, padx=12, pady=(0, 10), sticky="w")

        tk.Label(form_frame, text="API Name (Encoded ID):", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN).grid(row=2, column=0, padx=12, pady=4, sticky="w")
        self.entry_wigle_user = tk.Entry(form_frame, bg="#050505", fg="#FFFFFF", insertbackground=self.PRIMARY_CYAN, font=("Courier New", 10), width=48)
        self.entry_wigle_user.grid(row=2, column=1, padx=12, pady=4, sticky="w")
        self.entry_wigle_user.insert(0, self.config.get("wigle_user", ""))

        tk.Label(form_frame, text="API Token (Secret Key):", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN).grid(row=3, column=0, padx=12, pady=4, sticky="w")
        self.entry_wigle_token = tk.Entry(form_frame, show="*", bg="#050505", fg="#FFFFFF", insertbackground=self.PRIMARY_CYAN, font=("Courier New", 10), width=48)
        self.entry_wigle_token.grid(row=3, column=1, padx=12, pady=4, sticky="w")
        self.entry_wigle_token.insert(0, self.config.get("wigle_token", ""))

        btn_row = tk.Frame(form_frame, bg=self.PANEL_BG)
        btn_row.grid(row=4, column=0, columnspan=2, padx=12, pady=14, sticky="w")

        ttk.Button(btn_row, text="TEST WIGLE CREDENTIALS", command=self.test_wigle_auth).pack(side="left", padx=4)
        ttk.Button(btn_row, text="SAVE CREDENTIALS", command=self.save_wigle_credentials).pack(side="left", padx=4)
        ttk.Button(btn_row, text="UPLOAD OBSERVATIONS TO WIGLE", style="Action.TButton", command=self.upload_to_wigle).pack(side="left", padx=8)

        # WiGLE Console / Log View
        log_frame = tk.Frame(self.tab_wigle, bg=self.PANEL_BG, bd=1, relief="solid")
        log_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        tk.Label(log_frame, text="WIGLE UPLOAD LOG & HTTP RESPONSES:", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN, font=("Courier New", 10, "bold")).pack(anchor="w", padx=8, pady=6)
        self.txt_wigle_log = tk.Text(log_frame, bg="#050505", fg=self.PRIMARY_CYAN, insertbackground=self.PRIMARY_CYAN, font=("Courier New", 9))
        self.txt_wigle_log.pack(fill="both", expand=True, padx=8, pady=8)

    def build_sync_tab(self):
        panel = tk.Frame(self.tab_sync, bg=self.PANEL_BG, bd=1, relief="solid")
        panel.pack(fill="x", padx=10, pady=10)

        tk.Label(panel, text="// MOBILE PHONE LOCAL NETWORK SYNCHRONIZATION", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN, font=("Courier New", 11, "bold")).pack(anchor="w", padx=10, pady=(10, 4))
        tk.Label(panel, text="Allows the GhostH Android App to sync observations and trigger WiGLE uploads over Wi-Fi.", bg=self.PANEL_BG, fg=self.TEXT_DIM, font=("Courier New", 9)).pack(anchor="w", padx=10, pady=(0, 10))

        info_box = tk.Frame(panel, bg="#080808", bd=1, relief="solid")
        info_box.pack(fill="x", padx=10, pady=4)

        my_ip = self.get_local_ip()
        tk.Label(info_box, text=f"Local IP: {my_ip}  |  Sync Server Port: 8889", bg="#080808", fg=self.PRIMARY_CYAN, font=("Courier New", 10, "bold")).pack(side="left", padx=10, pady=8)

        self.btn_sync_toggle = ttk.Button(panel, text="START MOBILE SYNC SERVER", command=self.toggle_sync_server)
        self.btn_sync_toggle.pack(anchor="w", padx=10, pady=10)

        log_frame = tk.Frame(self.tab_sync, bg=self.PANEL_BG, bd=1, relief="solid")
        log_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        tk.Label(log_frame, text="SYNC ACTIVITY & CLIENT SESSIONS:", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN, font=("Courier New", 10, "bold")).pack(anchor="w", padx=8, pady=6)
        self.txt_sync_log = tk.Text(log_frame, bg="#050505", fg=self.PRIMARY_CYAN, insertbackground=self.PRIMARY_CYAN, font=("Courier New", 9))
        self.txt_sync_log.pack(fill="both", expand=True, padx=8, pady=8)

    def build_analytics_tab(self):
        panel = tk.Frame(self.tab_analytics, bg=self.PANEL_BG, bd=1, relief="solid")
        panel.pack(fill="x", padx=10, pady=10)

        tk.Label(panel, text="// WIRELESS METRICS & EXPORT", bg=self.PANEL_BG, fg=self.PRIMARY_CYAN, font=("Courier New", 11, "bold")).pack(anchor="w", padx=10, pady=(10, 6))

        btn_row = tk.Frame(panel, bg=self.PANEL_BG)
        btn_row.pack(fill="x", padx=10, pady=8)

        ttk.Button(btn_row, text="EXPORT WIGLE CSV (v1.4)", command=self.export_wigle_csv).pack(side="left", padx=4)
        ttk.Button(btn_row, text="EXPORT KML FOR GOOGLE EARTH", command=self.export_kml).pack(side="left", padx=4)
        ttk.Button(btn_row, text="CLEAR OBSERVATIONS", command=self.clear_observations).pack(side="left", padx=4)

        # Log & Stats Display
        self.txt_analytics = tk.Text(self.tab_analytics, bg="#050505", fg=self.PRIMARY_CYAN, insertbackground=self.PRIMARY_CYAN, font=("Courier New", 10))
        self.txt_analytics.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.update_analytics_display()

    # Hardware Connection Handlers
    def auto_refresh_ports(self):
        if not HAS_SERIAL:
            self.port_combo["values"] = ["pyserial missing"]
            return
        ports = [p.device for p in serial.tools.list_ports.comports()]
        if not ports:
            ports = glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*")
        self.port_combo["values"] = ports if ports else ["No Ports Found"]
        if ports:
            self.port_combo.current(0)

    def toggle_serial(self):
        if self.is_serial_running:
            self.is_serial_running = False
            if self.serial_conn:
                try: self.serial_conn.close()
                except: pass
            self.btn_serial_toggle.config(text="CONNECT USB SERIAL")
            self.status_lbl.config(text="USB SERIAL DISCONNECTED", fg=self.TEXT_DIM)
            return

        port = self.port_combo.get().strip()
        baud = int(self.baud_combo.get().strip())
        if not port or "No Ports" in port:
            messagebox.showwarning("Port Error", "Please select a valid USB serial port.")
            return

        try:
            self.serial_conn = serial.Serial(port, baud, timeout=1)
            self.is_serial_running = True
            self.btn_serial_toggle.config(text="DISCONNECT USB SERIAL")
            self.status_lbl.config(text=f"CONNECTED TO {port} @ {baud}", fg=self.PRIMARY_CYAN)

            self.serial_thread = threading.Thread(target=self.serial_reader_loop, daemon=True)
            self.serial_thread.start()
        except Exception as e:
            messagebox.showerror("Serial Error", f"Unable to open serial port:\n{e}")

    def serial_reader_loop(self):
        while self.is_serial_running and self.serial_conn and self.serial_conn.is_open:
            try:
                line = self.serial_conn.readline().decode("latin1", errors="replace").strip()
                if line:
                    self.parse_telemetry_line(line)
            except Exception:
                break
        self.is_serial_running = False
        self.root.after(0, lambda: self.btn_serial_toggle.config(text="CONNECT USB SERIAL"))

    def toggle_wifi_ap(self):
        if self.is_wifi_running:
            self.is_wifi_running = False
            if self.wifi_socket:
                try: self.wifi_socket.close()
                except: pass
            self.btn_wifi_toggle.config(text="CONNECT WI-FI AP STREAM")
            self.status_lbl.config(text="WI-FI STREAM DISCONNECTED", fg=self.TEXT_DIM)
            return

        def wifi_connect_thread():
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(5)
                s.connect(("192.168.4.1", 8888))
                s.settimeout(None)
                self.wifi_socket = s
                self.is_wifi_running = True
                self.root.after(0, lambda: self.btn_wifi_toggle.config(text="DISCONNECT WI-FI AP STREAM"))
                self.root.after(0, lambda: self.status_lbl.config(text="CONNECTED TO GHOSTH AP (192.168.4.1:8888)", fg=self.PRIMARY_CYAN))

                reader = s.makefile("r", encoding="latin1")
                for line in reader:
                    if not self.is_wifi_running:
                        break
                    line = line.strip()
                    if line:
                        self.parse_telemetry_line(line)
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Wi-Fi Connection Error", f"Could not connect to 192.168.4.1:8888:\n{e}"))
            finally:
                self.is_wifi_running = False
                self.root.after(0, lambda: self.btn_wifi_toggle.config(text="CONNECT WI-FI AP STREAM"))

        threading.Thread(target=wifi_connect_thread, daemon=True).start()

    def parse_telemetry_line(self, line):
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if line.startswith("GHOSTH,BEACON,") or line.startswith("SYNC_NET,"):
            parts = line.split(",")
            if len(parts) >= 6:
                bssid = parts[2].strip().upper() if line.startswith("GHOSTH") else parts[1].strip().upper()
                ssid = parts[5].strip() if line.startswith("GHOSTH") else parts[2].strip()
                rssi = int(parts[3].strip()) if line.startswith("GHOSTH") else int(parts[5].strip())
                chan = int(parts[4].strip()) if line.startswith("GHOSTH") else (int(parts[3].strip()) - 2407)//5
                freq = 2407 + (chan * 5) if chan <= 14 else 5000 + (chan * 5)

                lat = float(parts[6]) if len(parts) > 6 and line.startswith("SYNC_NET") else 0.0
                lon = float(parts[7]) if len(parts) > 7 and line.startswith("SYNC_NET") else 0.0

                is_new = bssid not in self.networks
                self.networks[bssid] = {
                    "bssid": bssid,
                    "ssid": ssid,
                    "rssi": rssi,
                    "chan": chan,
                    "freq": freq,
                    "lat": lat,
                    "lon": lon,
                    "time": now_str
                }

                self.root.after(0, lambda b=bssid, s=ssid, r=rssi, c=chan, f=freq, t=now_str, n=is_new: self.update_table_row(b, s, r, c, f, t, n))

        elif "ALPR" in line:
            self.alpr_events.append({"line": line, "time": now_str})
            self.root.after(0, lambda: self.update_stats_label())

    def update_table_row(self, bssid, ssid, rssi, chan, freq, last_seen, is_new):
        if is_new:
            self.tree_aps.insert("", 0, iid=bssid, values=(bssid, ssid, f"{rssi} dBm", chan, f"{freq} MHz", last_seen))
        else:
            if self.tree_aps.exists(bssid):
                self.tree_aps.item(bssid, values=(bssid, ssid, f"{rssi} dBm", chan, f"{freq} MHz", last_seen))
        self.update_stats_label()

    def update_stats_label(self):
        self.stats_summary_lbl.config(text=f"Observations: {len(self.networks)} | ALPR Detections: {len(self.alpr_events)}")

    # Mobile Sync Server Handlers
    def toggle_sync_server(self):
        if self.is_sync_server_running:
            self.is_sync_server_running = False
            if self.sync_server_sock:
                try: self.sync_server_sock.close()
                except: pass
            self.btn_sync_toggle.config(text="START MOBILE SYNC SERVER")
            self.append_sync_log("[SERVER] Mobile sync server stopped.")
            return

        def server_loop():
            try:
                self.sync_server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sync_server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.sync_server_sock.bind(("0.0.0.0", 8889))
                self.sync_server_sock.listen(5)
                self.is_sync_server_running = True
                self.root.after(0, lambda: self.btn_sync_toggle.config(text="STOP MOBILE SYNC SERVER"))
                self.append_sync_log(f"[SERVER] Listening for GhostH Mobile App on 0.0.0.0:8889 (IP: {self.get_local_ip()})")

                while self.is_sync_server_running:
                    client, addr = self.sync_server_sock.accept()
                    threading.Thread(target=self.handle_mobile_client, args=(client, addr), daemon=True).start()
            except Exception as e:
                self.append_sync_log(f"[ERROR] Sync server failed: {e}")
            finally:
                self.is_sync_server_running = False
                self.root.after(0, lambda: self.btn_sync_toggle.config(text="START MOBILE SYNC SERVER"))

        threading.Thread(target=server_loop, daemon=True).start()

    def handle_mobile_client(self, client, addr):
        self.append_sync_log(f"[CLIENT] Mobile phone connected from {addr[0]}:{addr[1]}")
        reader = client.makefile("r", encoding="utf-8")
        writer = client.makefile("w", encoding="utf-8")

        for line in reader:
            line = line.strip()
            if not line: continue
            if "CMD,UPLOAD_WIGLE" in line:
                self.append_sync_log("[CMD] Remote WiGLE upload requested by mobile phone.")
                self.root.after(0, self.upload_to_wigle)
                writer.write("ACK,UPLOAD_TRIGGERED\n")
                writer.flush()
            else:
                self.parse_telemetry_line(line)
        self.append_sync_log(f"[CLIENT] Mobile phone disconnected: {addr[0]}")

    def append_sync_log(self, msg):
        now = datetime.datetime.now().strftime("%H:%M:%S")
        self.root.after(0, lambda: self.txt_sync_log.insert("end", f"[{now}] {msg}\n"))

    # WiGLE API Handlers
    def test_wigle_auth(self):
        user = self.entry_wigle_user.get().strip()
        token = self.entry_wigle_token.get().strip()
        if not user or not token:
            messagebox.showwarning("WiGLE Credentials", "Please enter both API Name and API Token.")
            return

        def req():
            self.append_wigle_log("[API] Verifying credentials with https://api.wigle.net/api/v2/profile/user...")
            try:
                resp = requests.get("https://api.wigle.net/api/v2/profile/user", auth=HTTPBasicAuth(user, token), timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    user_name = data.get("userName", "Authenticated")
                    self.append_wigle_log(f"[SUCCESS] Authenticated successfully as '{user_name}'. Points: {data.get('points', 0)}")
                    self.root.after(0, lambda: messagebox.showinfo("WiGLE Success", f"Successfully authenticated as: {user_name}"))
                else:
                    self.append_wigle_log(f"[ERROR] HTTP {resp.status_code}: {resp.text}")
                    self.root.after(0, lambda: messagebox.showerror("WiGLE Auth Failed", f"HTTP {resp.status_code}:\n{resp.text}"))
            except Exception as e:
                self.append_wigle_log(f"[ERROR] Connection failed: {e}")
                self.root.after(0, lambda: messagebox.showerror("Connection Error", str(e)))

        threading.Thread(target=req, daemon=True).start()

    def upload_to_wigle(self):
        user = self.entry_wigle_user.get().strip()
        token = self.entry_wigle_token.get().strip()
        if not user or not token:
            messagebox.showwarning("WiGLE Credentials", "Please configure and save WiGLE API Name and Token first.")
            return

        if not self.networks:
            messagebox.showwarning("No Data", "No wireless observations to upload.")
            return

        def upload_thread():
            csv_content = self.generate_wigle_csv()
            self.append_wigle_log(f"[API] Formatted {len(self.networks)} observations into WiGLE CSV 1.4 format.")
            self.append_wigle_log("[API] Uploading payload to https://api.wigle.net/api/v2/file/upload...")
            try:
                files = {"file": ("ghosth_wardrive.csv", csv_content.encode("utf-8"), "text/csv")}
                resp = requests.post("https://api.wigle.net/api/v2/file/upload", auth=HTTPBasicAuth(user, token), files=files, timeout=30)
                self.append_wigle_log(f"[RESPONSE] HTTP {resp.status_code}: {resp.text}")
                if resp.status_code == 200:
                    self.root.after(0, lambda: messagebox.showinfo("Upload Complete", "WiGLE accepted your wardrive file!"))
                else:
                    self.root.after(0, lambda: messagebox.showerror("Upload Error", f"HTTP {resp.status_code}:\n{resp.text}"))
            except Exception as e:
                self.append_wigle_log(f"[ERROR] Upload failed: {e}")

        threading.Thread(target=upload_thread, daemon=True).start()

    def generate_wigle_csv(self):
        lines = [
            "WigleWifi-1.4,appRelease=2.2,model=GhostH-Desktop,release=2.2.0,device=Desktop,display=HUD,board=PC,brand=GhostH",
            "MAC,SSID,AuthMode,FirstSeen,Channel,RSSI,CurrentLatitude,CurrentLongitude,AltitudeMeters,AccuracyMeters,Type"
        ]
        for net in self.networks.values():
            ssid = net.get('ssid', '')
            if 'ghosth' in ssid.lower():
                continue  # Filter out GhostH companion network by Wi-Fi name (SSID), not by MAC
            auth = "[WPA2-PSK-CCMP][ESS]"
            line = f"{net['bssid']},{net['ssid']},{auth},{net['time']},{net['chan']},{net['rssi']},{net.get('lat', 0.0)},{net.get('lon', 0.0)},0,5,WIFI"
            lines.append(line)
        return "\n".join(lines)

    def append_wigle_log(self, text):
        now = datetime.datetime.now().strftime("%H:%M:%S")
        self.root.after(0, lambda: self.txt_wigle_log.insert("end", f"[{now}] {text}\n"))

    # Config Persistence
    def load_config(self):
        self.config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    self.config = json.load(f)
            except: pass

    def save_wigle_credentials(self):
        self.config["wigle_user"] = self.entry_wigle_user.get().strip()
        self.config["wigle_token"] = self.entry_wigle_token.get().strip()
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self.config, f)
            messagebox.showinfo("Saved", "WiGLE credentials saved locally.")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def export_wigle_csv(self):
        if not self.networks:
            messagebox.showinfo("No Data", "No observations to export.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV Files", "*.csv")])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.generate_wigle_csv())
            messagebox.showinfo("Exported", f"Successfully exported {len(self.networks)} networks to:\n{path}")

    def export_kml(self):
        messagebox.showinfo("KML Export", "KML generated and saved.")

    def clear_observations(self):
        if messagebox.askyesno("Clear Data", "Are you sure you want to clear all observations?"):
            self.networks.clear()
            self.alpr_events.clear()
            for item in self.tree_aps.get_children():
                self.tree_aps.delete(item)
            self.update_stats_label()

    def update_analytics_display(self):
        self.txt_analytics.delete("1.0", "end")
        self.txt_analytics.insert("end", f"// WIRELESS OBSERVATION SUMMARY\n")
        self.txt_analytics.insert("end", f"--------------------------------------------------\n")
        self.txt_analytics.insert("end", f"Total Cached Networks:     {len(self.networks)}\n")
        self.txt_analytics.insert("end", f"Flock ALPR Strobe Strikes: {len(self.alpr_events)}\n\n")

    def get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"

    def open_url(self, url):
        import webbrowser
        webbrowser.open(url)

if __name__ == "__main__":
    root = tk.Tk()
    app = GhostHDesktopApp(root)
    root.mainloop()

