#!/usr/bin/env bash
set -e

APP_NAME="ghosth-desktop"
DESKTOP_NAME="ghosth.desktop"
ICON_NAME="ghosth.png"

if [ "$(id -u)" -eq 0 ]; then
    INSTALL_BIN="/usr/local/bin"
    INSTALL_APPS="/usr/share/applications"
    INSTALL_ICONS="/usr/share/icons/hicolor/512x512/apps"
    INSTALL_PIXMAPS="/usr/share/pixmaps"
else
    INSTALL_BIN="$HOME/.local/bin"
    INSTALL_APPS="$HOME/.local/share/applications"
    INSTALL_ICONS="$HOME/.local/share/icons/hicolor/512x512/apps"
    INSTALL_PIXMAPS="$HOME/.local/share/pixmaps"
fi

echo "==> Uninstalling GhostH Tactical Desktop Suite..."
rm -f "$INSTALL_BIN/$APP_NAME"
rm -f "$INSTALL_APPS/$DESKTOP_NAME"
rm -f "$INSTALL_ICONS/$ICON_NAME"
rm -f "$INSTALL_PIXMAPS/$ICON_NAME"
rm -rf "$HOME/.local/share/ghosth"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$INSTALL_APPS" 2>/dev/null || true
fi

echo "==> GhostH uninstallation complete."
