# GhostH // Tactical Desktop Suite v2.2 ⚡

Cross-platform wardriving, WiGLE uploader, NodeMCU hardware companion & tactical reconnaissance workstation for Linux and Windows.

---

## 🚀 Features

* **App Icon**: Authentic GhostH Cyberpunk tactical app icon.
* **Linux App Integration**: One-click registration in your Linux Applications menu (`.desktop` launcher).
* **Hardware Ingestion**: Ingests serial telemetry from NodeMCU over USB (`115200` baud) or Wi-Fi TCP stream (`192.168.4.1:8888`).
* **Flock ALPR Strobe Discriminator**: Live alerts for 25Hz - 65Hz pulsed optical IR ALPR cameras.
* **WiGLE Direct API Uploader**: Validate WiGLE API credentials and upload wardriving sessions directly over HTTPS.
* **WiGLE CSV 1.4 Exporter**: Formats discovered networks into WiGLE CSV v1.4 with automatic privacy exclusion of `GHOSTH` SSIDs.
* **Mobile App LAN Sync**: Bi-directional LAN synchronization with the GhostH Android app over TCP port `8889`.

---

## 🐧 Linux Installation & Setup

### Option 1: One-Click Installer (Recommended)
Extract the package and run:
```bash
chmod +x install.sh
./install.sh
```
* GhostH will immediately be added to your system's **Applications Menu** / App Launcher.
* You can also start it from any terminal by typing:
  ```bash
  ghosth-desktop
  ```

### Option 2: Standalone Execution
Run the standalone binary directly without installing:
```bash
chmod +x ghosth-desktop-linux
./ghosth-desktop-linux
```
*(You can also click the "**ADD TO LINUX APPS**" button in the top-right corner of the app window at any time to register it)*.

### To Uninstall from Linux:
```bash
./uninstall.sh
```

---

## 🪟 Windows Setup

1. Double-click `run_windows.bat` or `ghosth-desktop.exe`.
2. Select your NodeMCU COM port (e.g., `COM3`) at `115200` baud and click **Connect USB Serial**.

---

## 🌐 Developer & Documentation
* Developer Website: [https://haybnz.web.app/](https://haybnz.web.app/)
* Official Wiki: [https://github.com/h9zdev/GHOSTH/wiki](https://github.com/h9zdev/GHOSTH/wiki)
