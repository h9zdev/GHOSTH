#!/usr/bin/env bash
set -e

APP_NAME="ghosth-desktop"
DESKTOP_NAME="ghosth.desktop"
ICON_NAME="ghosth.png"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if running as root or normal user
if [ "$(id -u)" -eq 0 ]; then
    INSTALL_BIN="/usr/local/bin"
    INSTALL_APPS="/usr/share/applications"
    INSTALL_ICONS="/usr/share/icons/hicolor/512x512/apps"
    INSTALL_PIXMAPS="/usr/share/pixmaps"
else
    INSTALL_BIN="$HOME/.local/bin"
    INSTALL_APPS="$HOME/.local/share/applications"
    INSTALL_ICONS="$HOME/.local/share/icons/hicolor/512x512/apps"
    INSTALL_PIXMAPS="$HOME/.local/share/pixmaps"
fi

mkdir -p "$INSTALL_BIN" "$INSTALL_APPS" "$INSTALL_ICONS" "$INSTALL_PIXMAPS"

echo "==> Installing GhostH Tactical Desktop Suite to $INSTALL_BIN..."

# 1. Install binary or python wrapper
if [ -f "$SCRIPT_DIR/ghosth-desktop-linux" ]; then
    cp "$SCRIPT_DIR/ghosth-desktop-linux" "$INSTALL_BIN/$APP_NAME"
    chmod +x "$INSTALL_BIN/$APP_NAME"
elif [ -f "$SCRIPT_DIR/ghosth_desktop.py" ]; then
    TARGET_DIR="$HOME/.local/share/ghosth"
    mkdir -p "$TARGET_DIR"
    cp "$SCRIPT_DIR/ghosth_desktop.py" "$TARGET_DIR/"
    if [ -f "$SCRIPT_DIR/ghosth_icon.png" ]; then
        cp "$SCRIPT_DIR/ghosth_icon.png" "$TARGET_DIR/"
    fi
    cat << EOF > "$INSTALL_BIN/$APP_NAME"
#!/usr/bin/env bash
exec python3 "$TARGET_DIR/ghosth_desktop.py" "\$@"
EOF
    chmod +x "$INSTALL_BIN/$APP_NAME"
fi

# 2. Install Icon
if [ -f "$SCRIPT_DIR/ghosth_icon.png" ]; then
    cp "$SCRIPT_DIR/ghosth_icon.png" "$INSTALL_ICONS/$ICON_NAME"
    cp "$SCRIPT_DIR/ghosth_icon.png" "$INSTALL_PIXMAPS/$ICON_NAME"
elif [ -f "$SCRIPT_DIR/ghosth.png" ]; then
    cp "$SCRIPT_DIR/ghosth.png" "$INSTALL_ICONS/$ICON_NAME"
    cp "$SCRIPT_DIR/ghosth.png" "$INSTALL_PIXMAPS/$ICON_NAME"
fi

# 3. Install Desktop entry
cat << EOF > "$INSTALL_APPS/$DESKTOP_NAME"
[Desktop Entry]
Version=1.0
Type=Application
Name=GhostH
GenericName=Tactical Wardrive & SIGINT Suite
Comment=GhostH RF Signal Intelligence, Wardriving & Surveillance Suite
Exec=$INSTALL_BIN/$APP_NAME
Icon=ghosth
Terminal=false
Categories=Network;Security;Utility;
Keywords=wardrive;wifi;alpr;sigint;wigle;ghosth;
StartupWMClass=ghosth-desktop
EOF

chmod +x "$INSTALL_APPS/$DESKTOP_NAME"

# 4. Update desktop & icon caches
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$INSTALL_APPS" 2>/dev/null || true
fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
    gtk-update-icon-cache -f -t "$INSTALL_ICONS/../.." 2>/dev/null || true
fi

echo "==> Installation complete!"
echo "==> GhostH is now registered in your Linux Applications menu."
echo "==> Launch it from your system application menu or run: $APP_NAME"
