#!/usr/bin/env bash
python3 ghosth_desktop.py

