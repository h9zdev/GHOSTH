# GhostH Desktop Suite (v2.2)

Cross-platform tactical desktop companion for GhostH wardriving, direct NodeMCU hardware ingestion, local network mobile synchronization, and direct WiGLE API uploading.

Compatible with **Windows**, **Linux**, and **macOS**.

---

## Features

1. **Direct NodeMCU Hardware Ingestion**:
   - Auto-scans USB Serial ports (`COMx` on Windows, `/dev/ttyUSB*` / `/dev/ttyACM*` on Linux) at 115200 baud.
   - Real-time display of incoming 802.11 beacon frames and Flock ALPR optical pulse alarms.
   - Optional Wi-Fi direct connection to NodeMCU access point (`192.168.4.1:8888`).

2. **Direct WiGLE API Uploader**:
   - Configure your WiGLE API Name (Encoded ID) and API Token (Secret Key).
   - Test authentication with 1 click.
   - Upload all discovered observations directly to WiGLE (`https://api.wigle.net/api/v2/file/upload`) in standard WiGLE CSV v1.4 format.

3. **Mobile Phone Local Network Synchronization**:
   - Built-in TCP sync server on port `8889`.
   - Android phone connects to the Desktop Suite over local Wi-Fi or GhostH AP.
   - 1-click sync of all mobile observations to desktop.
   - Trigger desktop WiGLE API upload directly from the phone.

4. **Export Options**:
   - Standard WiGLE CSV v1.4 export.
   - KML export for Google Earth and GIS mapping.

---

## Quick Start

### Windows
1. Make sure Python 3.8+ is installed on your Windows PC (from python.org with "Add to PATH" checked).
2. Double-click `run_windows.bat` (or open cmd and run `python ghosth_desktop.py`).

### Linux
1. Run directly:
   ```bash
   python3 ghosth_desktop.py
   ```
   *Or execute the pre-compiled standalone binary `ghosth-desktop-linux`:*
   ```bash
   chmod +x ghosth-desktop-linux
   ./ghosth-desktop-linux
   ```

---

## Dependencies
- `requests`
- `pyserial` (optional, for direct USB serial cable connection to NodeMCU)
- `tkinter` (built into Python)

