@echo off
title GhostH Desktop Suite
echo Starting GhostH Desktop Suite...
python ghosth_desktop.py
if %errorlevel% neq 0 (
    echo Python execution failed. Trying python3...
    python3 ghosth_desktop.py
)
pause

